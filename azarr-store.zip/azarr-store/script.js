// Optional interactivity
console.log("Azarr Store Ready");